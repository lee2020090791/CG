import numpy as np
from PIL import Image

class Sphere:
    def __init__(self, center, radius):
        self.center = np.array(center)
        self.radius = radius

def intersection_color(ray_origin, ray_direction, sphere):
    oc = ray_origin - sphere.center
    a = np.dot(ray_direction, ray_direction)
    b = 2.0 * np.dot(oc, ray_direction)
    c = np.dot(oc, oc) - sphere.radius * sphere.radius
    discriminant = b * b - 4 * a * c
    
    if discriminant < 0:
        # 교차하지 않는 경우 흰색 반환
        return (255, 255, 255)
    else:
        # 교차하는 경우 검은색 반환
        return (0, 0, 0)

def main():
    # 카메라 설정
    viewPoint = np.array([5, 4, 3])
    viewDir = np.array([-5, -4, -3])
    projNormal = np.array([5, 4, 3])
    viewUp = np.array([0, 1, 0])
    projDistance = 5
    viewWidth = 2.5
    viewHeight = 2.5
    
    # 구 객체 생성
    sphere = Sphere((0, 0, 0), 1)
    
    # 이미지 크기 설정
    width, height = 200, 200
    
    # 이미지 생성
    image = Image.new("RGB", (width, height), color="white")
    pixels = image.load()
    
    # 카메라 방향 벡터 설정
    aspect_ratio = width / height
    right = np.cross(viewDir, viewUp)
    right /= np.linalg.norm(right)
    up = np.cross(right, viewDir)
    up /= np.linalg.norm(up)
    
    # 이미지 픽셀에 대한 루프
    for y in range(height):
        for x in range(width):
            # 이미지 픽셀의 중심 위치 계산
            u = (x + 0.5) / width - 0.5
            v = (y + 0.5) / height - 0.5
            screen_point = (
                viewPoint
                + viewDir * projDistance
                + right * u * viewWidth * aspect_ratio
                + up * v * viewHeight
            )
            
            # 광선의 방향 벡터 설정
            ray_direction = screen_point - viewPoint
            ray_direction /= np.linalg.norm(ray_direction)
            
            # 광선과 구의 교차점의 색상 계산
            color = intersection_color(viewPoint, ray_direction, sphere)
            
            # 이미지에 색상 설정 (부동소수점을 정수로 변환하여 설정)
            pixels[x, y] = tuple(int(c) for c in color)
    
    # 이미지 저장
    image.save("output.png")

if __name__ == "__main__":
    main()
